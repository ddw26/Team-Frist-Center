# AntxAmp (X-role) 
# Technologies Used
## Data Cleaning and Analysis
Pandas will be used to clean the data and perform an exploratory analysis. Further analysis will be completed using Python.

## Database Storage
Postgres and SQLlite have both been tested and is the database we intend to use, and we will integrate to display the data.

## Machine Learning
SciKitLearn is the ML library we'll be using to create a classifier. Our training and testing setup is ___. 

## Dashboard
In addition to using a Flask template, we will also use Tableau for a fully functioning and interactive dashboard. It will be hosted on Tableau Public.

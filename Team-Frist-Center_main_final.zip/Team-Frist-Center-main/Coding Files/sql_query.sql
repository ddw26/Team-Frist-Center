
-- Show all rows in dataframes
SELECT *
FROM df_keys;

SELECT *
FROM df_values;


-- Clear dataframes
-- DELETE
-- FROM df_keys;

-- DELETE
-- FROM df_values;
